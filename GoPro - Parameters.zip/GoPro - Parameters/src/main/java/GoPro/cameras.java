package GoPro;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class cameras extends locators {

	WebDriver driver;
	public float price;
	public int numberofproducts;
	
	public cameras(WebDriver driver) {
		this.driver=driver;
	}	
	
	public void addheroblacktocart() {
		
		WebDriverWait wait = new WebDriverWait(driver, 5);
		driver.findElement(addtocartbutton).click();
		try {
			
		wait.until(ExpectedConditions.elementToBeClickable(chosecollors));
		driver.findElement(chosecollors).click();
		}
		
		catch(Exception e){
		System.out.println("No other collor choices");
		}
		
		wait.until(ExpectedConditions.elementToBeClickable(exiticon));
		driver.findElement(exiticon).click();
		
	}
	
	public void addherosilvertocart() {
		
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(addtocardbutton2));
		driver.findElement(addtocardbutton2).click();
		wait.until(ExpectedConditions.elementToBeClickable(exiticon));
		driver.findElement(exiticon).click();	
	
	}
	
	public void getheroblackprice() {
		
		String getprice = driver.findElement(heroblackprice).getText();
		String a = getprice.substring(1);
		price = Float.parseFloat(a);
		
	}
	
	public void getherosilverprice() {
		
		String getprice = driver.findElement(herosilverprice).getText();
		String b = getprice.substring(1);
		price = Float.parseFloat(b);
		
	}
	
	public void getcartnumber() {
		
		String getnumber = driver.findElement(By.className("gpn-cart-count")).getAttribute("innerText");
		numberofproducts = Integer.parseInt(getnumber);
	}

}
