package GoPro;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class homepage extends locators {
	
	WebDriver driver;
	public WebElement gdprbar;
	public int numberofproducts;
	public float price;
	public float total_price;
		
	public homepage(WebDriver driver) {
		this.driver=driver;
	}
	
	public void selectdriver(String browser) {
		
		switch(browser) {
			case "Chrome":
			driver = new ChromeDriver();  
			break;
			case "Firefox":
			driver = new FirefoxDriver();	  
			break;
			default:
			driver = new ChromeDriver();	  		
		}		
		}		
	public void gotocameras() {
		
		driver.findElement(cameras).click();
		//driver.switchTo().defaultContent();
		WebDriverWait wait = new WebDriverWait(driver, 5);
		
		try {
			
		wait.until(ExpectedConditions.elementToBeClickable(xtoclose));
		driver.findElement(xtoclose).click();
		driver.findElement(gdpr).click();
		}
		
		catch(Exception e) {
			System.out.println("No camera promotions. Proceed to cameras shop");
		}
		
	
	}
	public void gohome() {
		driver.findElement(gohome).click();
	}
	
	
	
	public void opencart() {
	
		driver.findElement(myaccount).click();
		try {
			WebDriverWait wait = new WebDriverWait(driver, 5);
			wait.until(ExpectedConditions.elementToBeClickable(addtocardbutton3));
			driver.findElement(addtocardbutton3).click();
		}
		catch(Exception e) {
			System.out.println("No bonus products");
		}
	}
		
	public void removecamera() {
		
		driver.findElement(removebutton).click();
	}

}
