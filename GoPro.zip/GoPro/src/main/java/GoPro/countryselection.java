package GoPro;
import org.openqa.selenium.WebDriver;

public class countryselection {

	public static String homeurl_ro = "https://www.gopro.com";
	public static String homeurl_es = "https://gopro.com/es/es/";
	public static String homeurl_de = "https://gopro.com/en/de";
	public static String homeurl_it = "https://gopro.com/en/it";



	WebDriver driver;
	public countryselection(WebDriver driver) {
		this.driver=driver;
	}	

	public void select(String country) {

		switch(country) {
		  case "Romania":
			  driver.get(homeurl_ro);
			  driver.manage().window().maximize();
		    break;
		  case "Spain":
			  driver.get(homeurl_es);
			  driver.manage().window().maximize();
		    break;
		  case "Italy":
			  driver.get(homeurl_it);
			  driver.manage().window().maximize();
			break;
		  default:
			  driver.get(homeurl_de);
			  driver.manage().window().maximize();
		}
	}

}
