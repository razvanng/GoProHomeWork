package GoProTests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import GoPro.homepage;
import GoPro.cameras;
import GoPro.countryselection;

public class RoTest {

	WebDriver driver = new ChromeDriver();
	cameras heroblack = new cameras(driver);
	cameras herosilver = new cameras(driver);
	homepage hero = new homepage(driver);
	countryselection selectted_country = new countryselection(driver);


		
		@BeforeTest
		public void opensite() {
		selectted_country.select("Romania");		
		}
		
		
		@Test(priority = 0)
		public void addcamera() {
		
		hero.gotocameras();
		heroblack.getheroblackprice();
		System.out.println(heroblack.price);
		heroblack.addheroblacktocart();
		WebElement NumberInCart = driver.findElement(By.className("gpn-cart-count"));
		Assert.assertTrue(NumberInCart.isDisplayed());
		heroblack.getcartnumber();
		
		System.out.println(heroblack.numberofproducts);
		hero.gotocameras();
		herosilver.getherosilverprice();
		System.out.println(herosilver.price);
		herosilver.addherosilvertocart();
		herosilver.getcartnumber();
		System.out.println(herosilver.numberofproducts);
		Assert.assertNotEquals(herosilver.numberofproducts,heroblack.numberofproducts);
		
		//hero.totalprice();
		//System.out.println(hero.total_price);
		//Assert.assertEquals(hero.total_price, herosilver.price+heroblack.price);
		}
		
		@Test(priority = 1)
		public void remove1stcamera() {
		
		hero.opencart();
		hero.removecamera();
		hero.gohome();
		herosilver.getcartnumber();
		Assert.assertEquals(heroblack.numberofproducts,herosilver.numberofproducts);
			
		}
		
		@Test(priority = 2)
		public void remove2ndcamera(){
		
		hero.opencart();
		hero.removecamera();
		WebElement EmptyCart = driver.findElement(By.className("cart-empty-container"));
		Assert.assertTrue(EmptyCart.isDisplayed());
		}
		
		@Test(priority = 3)
		
		public void negativetesting() {
		hero.gohome();
		hero.opencart();
		WebElement EmptyCartMessage = driver.findElement(By.className("gpn-cta"));
		Assert.assertFalse(EmptyCartMessage.isDisplayed());
		
		}
}
